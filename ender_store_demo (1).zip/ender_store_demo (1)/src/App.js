import React from 'react';

function App() {
  return (
    <div style={{ backgroundColor: '#000', color: '#fff', minHeight: '100vh', padding: '20px' }}>
      <header style={{ backgroundColor: '#4B0082', padding: '10px', borderRadius: '8px' }}>
        <h1 style={{ color: '#E6E6FA' }}>Ender Store</h1>
      </header>
      <main style={{ marginTop: '20px' }}>
        <h2>Welcome to Ender Store</h2>
        <p>Buy & Sell MM2 items using Enders (1 Ender = $1)</p>
        <section style={{ marginTop: '20px' }}>
          <h3>Sample Products</h3>
          <ul>
            <li>Sword - 10 Enders</li>
            <li>Gun - 20 Enders</li>
            <li>Rare Knife - 50 Enders</li>
          </ul>
        </section>
      </main>
    </div>
  );
}

export default App;