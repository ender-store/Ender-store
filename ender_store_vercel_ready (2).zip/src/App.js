import React from 'react';

function App() {
  return (
    <div style={{backgroundColor:'#000', color:'#fff', minHeight:'100vh', padding:'20px'}}>
      <h1>Ender Store</h1>
      <p>Welcome to Ender Store - Buy & Sell MM2 items using Enders (1 Ender = $1).</p>
      <ul>
        <li>Sword - 10 Enders</li>
        <li>Gun - 20 Enders</li>
        <li>Rare Knife - 50 Enders</li>
      </ul>
    </div>
  );
}

export default App;